# WhoIsMyVillain
Repo for website WhoIsMyVillain.com using AWS services (Lambda, DynamoDB), Express/NodeJS, and Serverless to provide inspiration for a fantasy villain.
