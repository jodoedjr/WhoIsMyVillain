JS for creating and loading DynamoDB tables adapted from:
https://docs.aws.amazon.com/sdk-for-javascript/v2/developer-guide/dynamodb-examples.html